# lip-reading
To detect the words spoken by a person based on his lip movements only, we employ two different approaches. One using Convolutional Neural Networks and other using Hidden Markov Model. 
